package com.example.trabajotarea;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    EditText txtNumeros;
    ProgressBar prgsNumero;
    TextView lblResult;


    TimePicker dpTiempo;
    DatePicker dpCalendario;
    boolean isRun = false;
    int contador = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InitializerControllers();
    }

    private void InitializerControllers(){
        dpTiempo = (TimePicker)findViewById(R.id.dpTiempo);
        dpCalendario = (DatePicker)findViewById(R.id.dpCalendario);
        txtNumeros = (EditText)findViewById(R.id.txtNumeros);
        prgsNumero = (ProgressBar)findViewById(R.id.prgsNumero);
        lblResult = (TextView)findViewById(R.id.lblResult);
    }
    public void SetearNumero(View v){
        int hora = dpTiempo.getHour();
        int minuto = dpTiempo.getMinute();

        int dia = dpCalendario.getDayOfMonth();
        int mes = dpCalendario.getMonth()+1;
        int year = dpCalendario.getYear();
        try {
            double porcentaje = Double.parseDouble(txtNumeros.getText().toString());

            final Timer t = new Timer();
            if(!isRun && porcentaje<=100 && porcentaje>=1){
                TimerTask tt = new TimerTask(){
                    public void run(){
                        contador++;
                        prgsNumero.setProgress(contador);
                        if(contador==porcentaje){
                            t.cancel();
                        }

                    }
                };
                t.schedule(tt,0,100);
            }

            else if(porcentaje>100){
                Toast.makeText(this, "El porcentaje máximo de la barra es 100%",Toast.LENGTH_SHORT).show();
            }
            else if(porcentaje==0){
                Toast.makeText(this,"El porcentaje mínimo de la barra es de 1%",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, "Limpie el resultado y vuelva a intentar",Toast.LENGTH_SHORT).show();
            }
            isRun=true;

            lblResult.setText("Es el día "+dia
                    +" de el mes "+mes
                    +" del "+year
                    +"\ny su hora "+hora
                    +":"+minuto);
        }catch(NumberFormatException e){
            Toast.makeText(this, "Solo puede ingresar números: ",Toast.LENGTH_SHORT).show();
        }
    }

    public void ResetearNumero(View v){
        prgsNumero.setProgress(0);
        txtNumeros.setText("");
        lblResult.setText("");
        isRun=false;
        contador=0;
    }

}